import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class InterfaceGrafica extends JFrame implements ActionListener {
	JButton botao1 = new JButton("Mensagem 1");
	JButton botao2 = new JButton("Mensagem 2");
	JButton botao3 = new JButton("Mensagem 3");
	
public InterfaceGrafica(){	
	    botao1.addActionListener(this);
	    botao2.addActionListener(this);
	    botao3.addActionListener(this);
	    
	    //Desabilita o layout padrão
	    setLayout(null);
	    
	    //Criando os botões
		botao1.setBounds(50, 300, 120, 30);
		botao2.setBounds(200, 300, 120, 30);
		botao3.setBounds(350, 300, 120, 30);
		add(botao1);
		add(botao2);
		add(botao3);
		
	    //Frane
		setTitle("Janela de Evento");
		setSize(500, 500);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setResizable(false);
		setVisible(true);
		
	}	

public void ActionPerformed(ActionEvent evento) {
	if(evento.getSource() == botao1){
		JOptionPane.showMessageDialog(null, "Teste 01");
	}
	else if (evento.getSource() == botao2){
		JOptionPane.showMessageDialog(null, "Teste 02");
	}
	else if (evento.getSource() == botao3){
		System.exit(0);																																																						
	}
}

public static void main(String[] args) {
		 new InterfaceGrafica();		 
	}

}


