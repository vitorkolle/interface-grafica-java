import java.awt.Color;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class Cadastro extends JFrame{
	JButton btnMensagem = new JButton("Mensagem");
	JButton btnLimparNome = new JButton("Limpar nome");
	JButton btnSair = new JButton("Sair");
	
	JLabel lblNome = new JLabel("Nome");
	JLabel lblAnoDeNascimento = new JLabel("Ano de Nascimento");
	
	JTextField txtNome = new JTextField();
	JTextField txtAnoNascimento = new JTextField();
	
	
	public Cadastro(){
		setLayout(null);
		btnMensagem.setBounds(50,300,120,30);
		btnLimparNome.setBounds(200,300,110,30);
		btnSair.setBounds(340,300,100,30);
		add(btnLimparNome);
		add(btnMensagem);
		add(btnSair);
		
		lblNome.setBounds(100, 50, 100, 20);
		lblAnoDeNascimento.setBounds(100, 100, 110, 20);
		add(lblAnoDeNascimento);
		add(lblNome);
		
		txtNome.setBounds(220, 50, 200, 30);
		txtAnoNascimento.setBounds(220, 100, 100, 30);
		add(txtAnoNascimento);
		add(txtNome);
		
		setTitle("Cadastro de Produto");
		setSize(500, 400);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setBackground(Color.cyan);
		setResizable(false);
		setVisible(true);
		
	}
	
	public static void main(String[] args) {
		new Cadastro();
	}
	
}
